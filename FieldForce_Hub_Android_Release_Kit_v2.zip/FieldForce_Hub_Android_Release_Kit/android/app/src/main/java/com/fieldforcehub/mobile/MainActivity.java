package com.fieldforcehub.mobile;

import com.google.androidbrowserhelper.trusted.LauncherActivity;

// TWA keeps Chrome web-origin storage, Supabase Google OAuth and web push intact.
// Chrome only hides the address bar after the origin serves the correct assetlinks.json.
public final class MainActivity extends LauncherActivity {}
