# FieldForce Hub: direct Android APK distribution

**This is build SOURCE, not a compiled APK.** It is deliberately independent of the web app: do not overwrite `index.html`, `app.js`, `styles.css`, Supabase settings, OneSignal files or any existing catalogue assets. The Android app opens the **existing** FieldForce Hub via Android Trusted Web Activity (TWA) to retain existing browser-origin Supabase/Google sign-in and OneSignal web-push behavior where supported. All app features still require the live web server and network.

**Public display name:** `FieldForce Hub`  
**Android ID:** `com.fieldforcehub.mobile`  
**Current website origin:** `https://mehedialimayon-del.github.io`  
**App start path:** `/salesman-performance-app/`

## 1. Upload these sidecar source files

Copy the **`android/`** folder and **`.github/workflows/fieldforce-android-apk.yml`** file to the *root* of the **existing** `salesman-performance-app` GitHub repository. Do not delete or replace anything else. The workflow uses existing `an-logo.png` as icon, and downloads Android build dependencies on GitHub's own runners.

If ChatGPT's GitHub integration refuses repository writes with `403 Resource not accessible by integration`, reconnect it with repository write access if available, or upload these two paths using GitHub's `Add file > Upload files` on your device. Connector "admin" display alone does not guarantee write access.

## 2. Build TEST APK without secrets

Go to repository **Actions > FieldForce Hub - Android APK > Run workflow**, select **test** and run. The workflow also builds a test APK automatically when these new paths arrive on `main`. Download the Actions artifact `FieldForce-Hub-Android-...`, unzip it and find `FieldForce-Hub-TEST.apk`. **Only internal test**: standard Android debugging signature, and unverified TWA may show an address bar. Test real Google sign-in, SR permissions, sales sync and notifications on an Android phone.

## 3. Create one persistent, secret production signing key

Do this once in a trusted local environment, NOT in the public repo:

```bash
keytool -genkeypair -v -keystore ffh-release.jks -alias ffh-release -keyalg RSA -keysize 3072 -validity 10000
```

Store the keystore and passphrases safely for **every later update**. A lost signing key can prevent seamless updates. Convert the `.jks` to base64 locally (`base64 -w0 ffh-release.jks` on Linux; other systems have different commands). Never post the keystore, base64 text or passwords in chat or commit them to GitHub. Add exactly four encrypted **Actions repository secrets**:

- `FFH_KEYSTORE_B64`: base64 of that private `.jks` file
- `FFH_KEYSTORE_PASS`: the keystore password
- `FFH_KEY_ALIAS`: `ffh-release`
- `FFH_KEY_PASS`: the key password

Then **Actions > FieldForce Hub - Android APK > Run workflow**, select **production**. Download the artifact and extract `FieldForce-Hub.apk` (signed) and `assetlinks.json` (generated for the actual release certificate).

## 4. REQUIRED to remove website/browser URL bar

Your app is hosted inside a **project** GitHub Pages path. A correct Android Digital Asset Links declaration for that origin must be served at the **HOST ROOT**:

`https://mehedialimayon-del.github.io/.well-known/assetlinks.json`

It **will not work** at `/salesman-performance-app/.well-known/assetlinks.json`. As this GitHub Pages user root is a **separate** site, create/control the root user Pages repository named `mehedialimayon-del.github.io`, publish the **generated** `assetlinks.json` in `.well-known/`, and check with an incognito browser that the root URL serves JSON over HTTPS with no redirect. Alternately move the web app to a domain you control and update the Android manifest's origin/path BEFORE producing the APK, then serve the file at that domain root.

**Without host-root verification the app may show its real website URL in a Chrome Custom Tab**, even though SRs receive only an APK attachment. The APK can always be reverse engineered to recover the origin, even with verification; no wrapper can absolutely conceal the server.

Only publish the assetlinks file from your **production** signing key, unless you deliberately include additional test fingerprints. Publishing the file is not automated by this ZIP, because the existing GitHub app integration currently cannot write the user's repository, let alone a second root repository.

## 5. Distribute directly, not by web link

Send the actual `FieldForce-Hub.apk` file on WhatsApp, direct chat, Drive attachment, or your own managed app distributor. Recipients will not need a GitHub or website link. Android may prompt to allow installing from the sending app. Always test on one device before wider distribution. For updates, reuse the SAME signing key and increment `versionCode` in `android/app/build.gradle.kts` before rebuilding.

**Limits:** Site-side changes update in the installed shell, but the phone still loads the remote website and needs internet. Android-specific permissions, Google OAuth and push need a real-device test, not a successful CI build alone. The DEBUG test APK must not be described as final or production-ready.
